package org.zws.text;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.zws.templates.Result;
import org.zws.util.GetConnectionByJdbc;

import freemarker.template.Configuration;
import freemarker.template.Template;

public class Driver {
	public static void main(String[] args) {
		//readFromDataBase("student");
		autoGenerateTagertCode(typeConvert(readFromDataBase("student")),"student");
	}
	public static List<Result> readFromDataBase(String tableName){
		List<Result> results=new ArrayList<Result>();
		Connection con=GetConnectionByJdbc.getConnection();
		PreparedStatement psmt=null;
		ResultSet rs=null;
		String sql="select * from "+tableName;
		try {
			psmt=con.prepareStatement(sql);
			rs=psmt.executeQuery();
			ResultSetMetaData rsmd=rs.getMetaData();
			int size=rsmd.getColumnCount();
			for(int i=1;i<=size;i++) {
					results.add(new Result(rsmd.getColumnTypeName(i), rsmd.getColumnName(i)));
			}
			return results;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			GetConnectionByJdbc.closeAll(con, psmt, rs);
		}
		return null;
	}
	//�Զ�����domain�࣬mapper�ͽӿ���
	public static void autoGenerateTagertCode(List<Result> result,String tableName) {
		//1.����freeMark����ʵ��
				Configuration congConfiguration=new Configuration();
				//2.��ȡģ��·��
				try {
					congConfiguration.setDirectoryForTemplateLoading(new File("D:\\javaproject\\CodeGenerator\\src\\org\\zws\\templates"));
					//3.����mapperģ���ļ�,domainģ���ļ��ͽӿ��ļ�
					Template template1=congConfiguration.getTemplate("mapper.ftl");
					Template template2=congConfiguration.getTemplate("domain.ftl");
					Template template3=congConfiguration.getTemplate("interface.ftl");
					//4.�������ɵ�·��
					File targetFile1=new File("D:\\javaproject\\CodeGenerator\\src\\org\\zws\\mapper"+"\\mapper.xml");
					File targetFile2=new File("D:\\javaproject\\CodeGenerator\\src\\org\\zws\\domain\\"+tableName.substring(0,1).toUpperCase()+tableName.substring(1).toLowerCase()+".java");
					File targetFile3=new File("D:\\javaproject\\CodeGenerator\\src\\org\\zws\\dao\\I"+tableName.substring(0,1).toUpperCase()+tableName.substring(1).toLowerCase()+"Dao.java");
					//5.���������
					Writer out1=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(targetFile1),"utf-8"));
					Writer out2=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(targetFile2),"utf-8"));
					Writer out3=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(targetFile3),"utf-8"));
					//6.��������
					Map<String,Object> data1=new HashMap<String, Object>();
					data1.put("namespace", "org.zws.mapper."+tableName.substring(0,1).toUpperCase()+tableName.substring(1).toLowerCase());
					data1.put("voName", tableName);
					data1.put("tableName", tableName);
					data1.put("fields", result);
					template1.process(data1, out1);
					Map<String,Object> data2=new HashMap<String, Object>();
					data2.put("packageName", "org.zws.domain");
					data2.put("className", tableName.substring(0,1).toUpperCase()+tableName.substring(1).toLowerCase());
					data2.put("fields", result);
					template2.process(data2, out2);
					Map<String,Object> data3=new HashMap<String, Object>();
					data3.put("packageName", "org.zws.dao");
					data3.put("className", "I"+tableName.substring(0,1).toUpperCase()+tableName.substring(1).toLowerCase()+"Dao");
					data3.put("voName", tableName.substring(0,1).toUpperCase()+tableName.substring(1).toLowerCase());
					data3.put("name", tableName.toLowerCase());
					template3.process(data3, out3);
					out1.close();
					out2.close();
					out3.close();
					System.out.println("����ɹ�");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}
	//�����ݿ�����ת��Ϊjava����
	public static List<Result> typeConvert(List<Result> results){
		for(int i=0;i<results.size();i++) {
			Result rs=results.get(i);
			switch(rs.getKey()) {
			case "DOUBLE":rs.setKey("double");break;
			case "VARCHAR":rs.setKey("String");break;
			case "INT":rs.setKey("int");break;
			case "INTEGER":rs.setKey("int");break;
			case "DATE":rs.setKey("Date");break;
			}
		}
		return results;
	}
}
